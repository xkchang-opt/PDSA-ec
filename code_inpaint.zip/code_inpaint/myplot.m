
    %% plot-result
    fprintf ('Image=%s,  Tol=%e\n',ImageName,Tol);
    fprintf ('PDHG1:  %d/%f/%f\n',size(t_pdhg1,2)-1,t_pdhg1(1,end),SNR_pdhg1(1,end));
    fprintf ('PDHG:  %d/%f/%f\n',size(t_pdhg,2)-1,t_pdhg(1,end),SNR_pdhg(1,end));

     fprintf ('GRPDA:  %d/%f/%f\n',size(t_grpda,2)-1,t_grpda(1,end),SNR_grpda(1,end));
     fprintf ('PDS:  %d/%f/%f\n',size(t_pds,2)-1,t_pds(1,end),SNR_pds(1,end));
     fprintf ('PDS2:  %d/%f/%f\n',size(t_pds2,2)-1,t_pds2(1,end),SNR_pds2(1,end));
    % 
    % fprintf ('depda:  %d/%f/%f\n',size(t_depda,2)-1,t_depda(1,end),SNR_depda(1,end));

    figure(6)
    plot((obj_pdhg1-obj)/obj,'b-','DisplayName','CP-PDHG')
    hold on;
    plot((obj_pdhg-obj)/obj,'k--','DisplayName','CP-PDHG (relaxed)')
    plot((obj_grpda-obj)/obj,'m-','DisplayName','PDAc')
    plot((obj_pds-obj)/obj,'c--','DisplayName','Alg.3.1 ($\tau=\sigma=\sqrt{5}/L$)')
    plot((obj_pds2-obj)/obj,'r-','DisplayName','Alg.3.1($\tau=1/L, \sigma=5/L$)')
    xlabel('Iterations','Interpreter','latex','FontSize',14)
    ylabel({'$e_{\mbox{obj}}(x_n)$'},'Interpreter','latex','FontSize',14)
    set(gca,'FontSize',14,'LineWidth',2);
    set(gca,'yscale','log');
    ylim([6e-4 1e-1]);
    legend show;


figure(5);imshow(reshape(x_pds, [n, n, 3]),'border', 'tight');





