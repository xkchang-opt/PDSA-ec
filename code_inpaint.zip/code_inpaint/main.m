%% Algorithms3.1
% �㷨����psi = 1.618;
th = 0.99/5;
eta = 7/6;
gam =  (2-th)*(2-eta);
r = 0.4;

tau = r*sqrt(gam)/L;   %
sigma = sqrt(gam)/(r*L);
[x_pds, obj_pds, SNR_pds,t_pds] = PDS(parameters,th,eta,tau,sigma);


tau = r*1/L;   %
sigma = 1.5/(r*L);
[x_pds2, obj_pds2, SNR_pds2,t_pds2] = PDS(parameters,th,eta,tau,sigma);
%  figure(1);imshow(reshape(x_pds, [n, n, 3]),'border', 'tight');

%% CP-PDHG
tau = r * 1/L;   %He-3
sigma = 1/r * 1/L;
sita=1;
relax = 1;
[x_pdhg1,obj_pdhg1, SNR_pdhg1,t_pdhg1] = PDHG(parameters,tau,sigma,sita,relax);

relax = 1.5;
[x_pdhg,obj_pdhg, SNR_pdhg,t_pdhg] = PDHG(parameters,tau,sigma,sita,relax);

%% GRPDA
psi = 1.6;
gam = 1.6;
tau = r*sqrt(gam)/L;   
sigma = sqrt(gam)/(r*L);
[x_grpda,obj_grpda, SNR_grpda,t_grpda] = GRPDA(parameters,psi,tau,sigma);

