function  [x, obj, SNR,time]= PDHG(parameters,tau,sigma,sita,relax)
    %% 
    % ���������
    %       z������mask��������ͼ��
    %       l��ԭͼ
    %       A��B��lamda���������
    %       Tol���㷨��ֹ��������������ޣ�
    %       sita��PDHG�����Ʋ���
    disp('**********************************************************')
    if relax >1
        disp('Chambolle-Pock PDA for image inpainting(relaxed version)')
    else
        disp('Chambolle-Pock PDA for image inpainting')
    end
        
    disp('**********************************************************')
    %% pdhg�㷨���
    z = parameters{1,1};
    I = parameters{2,1};
    A = parameters{3,1};
    B = parameters{4,1};
    lamda = parameters{5,1};
    Iter_max = parameters{6,1};
    Tol = parameters{7,1};
    obj0 = parameters{8,1};
    %��ʼ��x0,y0
    x=z;
    y=A*x;
    Ax = A*x;
    i=1;
    
    NI = norm(I(:));
    SNR(i) = 20*log10(NI/(norm(x(:)-I(:)))); %SR(itr)
    obj(i) = lamda/2*norm(B.*x-z)^2 + norm(Ax,1);
    time(i)=0;
    i=i+1;
    tic
    while i <=Iter_max 
        Axpre = Ax;
        ypre = y;
        xpre = x;
        
        %����x_n
        x = prox_tau_g(xpre - tau * (A'*y), tau,lamda,B,z);
        x = min(max(x, 0), 1);
        Ax = A*x;
        
        %����xbar_n
        Axbar = Ax + sita*(Ax - Axpre);
        %����y_n
        y = ypre + sigma*(Axbar);
        y = min(max(y,-1), 1);
        
        time(i)=toc;
        SNR(i) = 20*log10(NI/(norm(x(:)-I(:)))); %SR(itr)
        obj(i) = lamda/2*norm(B.*x-z)^2 + norm(Ax,1);
        if abs(obj(i)-obj0)/obj0<Tol;  i 
            break; 
        else
            if relax >1
                x = xpre + relax*(x - xpre);
                Ax = Axpre + relax*(Ax - Axpre);
                y = ypre + relax*(y - ypre);
            end
        end  

        i=i+1;
    end
end











