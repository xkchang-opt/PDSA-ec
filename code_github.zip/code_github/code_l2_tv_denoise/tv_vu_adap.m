function [u, gap, time] = tv_vu_adap(f, maxits, maxtime, est, lambda, relax,step, mode)
    % VU for L^2-TV denoising demonstration script
    % Vu BC (2013)
    % A splitting algorithm for dual monotone inclusions involving cocoercive operators.
    % Advances in Computational Mathematics 38(3):667-681
    % --------------------------------------------
    %
    %    
    % mode (optional) - demonstration mode
    %      'demo' (default) - demonstrate the method
    %      'iter' - record primal-dual gap for a fixed number of iterations
    %      'time' - record primal-dual gap for a fixed time interval
    %      'tol'  - record iterations/time to reach a certain tolerance
    %      'all'  - perform all tests
    %    
    % mode: 0 - demo, 1 - est, 2 - iter, 3 - time
    
    disp('**********************************************************')
    if relax >1
        disp('Chambolle-Pock PDA for image denoising(relaxed version)')
    else
        disp('Chambolle-Pock PDA for image denoising')
    end
        
    disp('**********************************************************') 

    tstart = tic; %for comparison with time 
    gap = zeros(maxits,1);
    time = zeros(maxits,1);

    dxp = @(u)diffop(u,2,0);
    dxm = @(u)diffop(u,2,1);
    dyp = @(u)diffop(u,1,0);
    dym = @(u)diffop(u,1,1);
    
    [m,n] = size(f);
    
    u = f;
    v = zeros(m,n,2);
   tau = step{1,1};
   sig  = step{2,1};
   alp = 0.5; eta = 0.95; del = 1.5; s = 255;
   div_v = dxm(v(:,:,1)) + dym(v(:,:,2));  %% -K^*v
   dxp_u = dxp(u);
   dyp_u = dyp(u);
    for k = 1:maxits          
        
        p = (u + tau*(div_v + f))/(1 + tau);     %% x = P_tau g (x - tau K^*v)
        y = 2*p - u;
        
        
        vt(:,:,1) = v(:,:,1) + sig*(dxp(y));
        vt(:,:,2) = v(:,:,2) + sig*(dyp(y));
        q = reproject(vt, lambda);
        
        if relax >1
           u1 = u + relax*(p - u);       
           v1 = v + relax*(q - v);
        else
            u1 = p; v1 = q; 
        end
        %%%%%%%%%%%%%%% gap 
        dxp_u1 = dxp(u1);
        dyp_u1 = dyp(u1);
        % fro norm of u -f
        g1 = (norm(u1 - f,'fro'))^2/2;
        % TV norm
        g2 = lambda*sum(sum(sqrt(dxp_u1.^2 + dyp_u1.^2)));     
    
        % dual
        div_v1 = dxm(v1(:,:,1)) + dym(v1(:,:,2));
        g3 = (norm(div_v1, 'fro'))^2/2;
        % inner product
        g4 = sum(sum(f.*div_v1));
        
        %%%%%%%%%%%%%%%%% test modes

        gap(k) = (g1+g2+g3+g4)/(n*m);
        time(k) = toc(tstart);
        
        
        p_inf = norm((u-u1)/tau+(div_v-div_v1),1);
        dd1= (v(:,:,1) - v1(:,:,1))/sig - (dxp_u-dxp_u1);
        dd2= (v(:,:,2) - v1(:,:,2))/sig - (dyp_u-dyp_u1);
        d_inf = sum(sum(sqrt(dd1.^2 + dd2.^2)))/s;
        [tau,sig,alp] = adaptive_step(tau,sig,p_inf,d_inf,alp,eta,del);

        u = u1; v = v1; 
        dxp_u = dxp_u1;
        dyp_u = dyp_u1;
        div_v = div_v1;
        
        if (mode <= 1) && (gap(k) < est)
            fprintf('Iter    Time   gap \n');
            fprintf('%d  %9.1f  %9.1e \n', k, time(k), gap(k));
            break;
        end
        
%         if (mode == 0) && (mod(k, 10) == 0) 
%             imagesc(p); colormap(gray(256));
%             fprintf('Iteration %d: The primal-dual gap is %e.\n', k, gap(k));
%             drawnow;
%         end
        
        if (mode == 3) && (time(k) > maxtime)
            break;
        end
    end

    u = p;
    gap = gap(1:k);
    time = time(1:k);    
end
