function [tau,sig,alp] = adaptive_step(tau,sig,p_inf,d_inf,alp,eta,del);

 if p_inf > del*d_inf
     tau = tau/(1-alp);
     sig = sig*(1-alp);
     alp = alp*eta;
 elseif p_inf < d_inf/del
     tau = tau*(1-alp);
     sig = sig/(1-alp);
     alp = alp*eta;
 end








end