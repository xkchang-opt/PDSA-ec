MATLAB test framework for L^2-TV denoising
------------------------------------------

These scripts implement the methods mentioned in Subsection 7.1.1 of [2].

l2_tv_alg2.m - Accelerated primal-dual forward-backward algorithm
               ALG2 [3]
l2_tv_dr.m   - Primal-dual Douglas-Rachford splitting algorithm with
               DCT-based implicit step (Remark 2.9 in [4])
l2_tv_dr1.m  - Primal-dual inexact Douglas-Rachford type splitting
               algorithm 1 (Algorithm 3.1 in [1])
l2_tv_dr2.m  - Primal-dual inexact Douglas-Rachford type splitting
               algorithm 2 (Algorithm 3.2 in [1])
l2_tv_ms.m   - Primal-dual forward-backward-forward type algorithm
               based on monotone+skew operator splitting [4]
l2_tv_pdrq.m - Preconditioned Douglas-Rachford algorithm for
               linear-quadratic functionals [2]
l2_tv_vu.m   - Primal-dual forward-backward type algorithm [5]

References:

[1] Bot RI, Hendrich C (2013)
    A Douglas-Rachford type primal-dual method for solving inclusions with
    mixtures of composite and parallel-sum type monotone operators.
    SIAM Journal on Optimization 23(4):2541-2565

[2] Bredies K, Sun HP (2015)
    Preconditioned Douglas-Rachford algorithms for TV- and TGV-regularized
    variational imaging problems.
    Journal of Mathematical Imaging and Vision 52(3):317-344

[3] Chambolle A, Pock T (2011)
    A first-order primal-dual algorithm for convex problems with
    applications to imaging.
    Journal of Mathematical Imaging and Vision 40(1):120-145

[4] Briceno-Arias L, Combettes PL (2011)
    A monotone+skew splitting model for composite monotone inclusions
    in duality.
    SIAM Journal on Optimization 21(4):1230-1250
    
[5] Vu BC (2013)
    A splitting algorithm for dual monotone inclusions involving
    cocoercive operators.
    Advances in Computational Mathematics 38(3):667-681
