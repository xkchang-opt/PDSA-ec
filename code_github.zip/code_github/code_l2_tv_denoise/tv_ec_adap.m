function [u, gap, time] = tv_ec_adap(f, maxits, maxtime, est, lambda, step, mode)
    % VU for L^2-TV denoising demonstration script
    % 
    % A primal-dual splitting algorithm with convex combination and larger
    % step sizes for composite monotone inclusion problems
    %   Xiaokai Chang��Junfeng Yang��Jianchao Bai��Jianxiong Cao.
    % --------------------------------------------   
    % mode (optional) - demonstration mode
    %      'demo' (default) - demonstrate the method
    %      'iter' - record primal-dual gap for a fixed number of iterations
    %      'time' - record primal-dual gap for a fixed time interval
    %      'tol'  - record iterations/time to reach a certain tolerance
    %      'all'  - perform all tests
    %    
    % mode: 0 - demo, 1 - est, 2 - iter, 3 - time
    
    disp('**********************************************************')
    disp('Alg.3.1 with adaptive step sizes')
    disp('**********************************************************') 

   
    gap = zeros(maxits,1);
    time = zeros(maxits,1);

    dxp = @(u)diffop(u,2,0);
    dxm = @(u)diffop(u,2,1);
    dyp = @(u)diffop(u,1,0);
    dym = @(u)diffop(u,1,1);
    
    [m,n] = size(f);
    
    u = f;
    z = u;
    Kz(:,:,1) = dxp(z);
    Kz(:,:,2) = dyp(z);
    Ku = Kz;
    Ku_Kz = Ku - Kz;
    
    v = zeros(m,n,2);
    
   th = step{1,1};
   eta = step{2,1};
   tau = step{3,1};
   sig  = step{4,1};
   alp = 0.5; eta1 = 0.95; del = 1.5; s = 255;
   
   
   div_v = dxm(v(:,:,1)) + dym(v(:,:,2));  %% -K^*v
   dxp_u = dxp(u);
   dyp_u = dyp(u);
   
   tstart = tic; %for comparison with time 
   
    for k = 1:maxits 
        z = z + th * (u-z);
        Kz = Kz + th * Ku_Kz;

        u1 = (z + tau*(div_v + f))/(1 + tau);     %% x = P_tau g (x - tau K^*v)
 
        Ku(:,:,1) = dxp(u1);
        Ku(:,:,2) = dyp(u1);
        
        vt = v + sig * Ku;
        Ku_Kz = Ku - Kz;
        if eta ==1
             v1 = reproject(vt, lambda) + sig*th* Ku_Kz;
        else
             v1 = (1-eta)*v + eta * reproject(vt, lambda) + sig*th* Ku_Kz;
        end

        %%%%%%%%%%%%%%% gap 
   
        % fro norm of u -f
        g1 = (norm(u1 - f,'fro'))^2/2;
        % TV norm
        g2 = lambda*sum(sum(sqrt(Ku(:,:,1).^2 + Ku(:,:,2).^2)));     
    
        % dual
        div_v1 = dxm(v1(:,:,1)) + dym(v1(:,:,2));
        g3 = (norm(div_v1, 'fro'))^2/2;
        % inner product
        g4 = sum(sum(f.*div_v1));
        
        %%%%%%%%%%%%%%%%% test modes

        gap(k) = (g1+g2+g3+g4)/(n*m);
        time(k) = toc(tstart);
        
        p_inf = norm((u-u1)/tau+(div_v-div_v1),1);
        dd1= (v(:,:,1) - v1(:,:,1))/sig - (dxp_u-Ku(:,:,1));
        dd2= (v(:,:,2) - v1(:,:,2))/sig - (dyp_u-Ku(:,:,2));
        d_inf = sum(sum(sqrt(dd1.^2 + dd2.^2)))/s;
        [tau,sig,alp] = adaptive_step(tau,sig,p_inf,d_inf,alp,eta1,del);
        
        u = u1; v = v1; 
        dxp_u = Ku(:,:,1);
        dyp_u = Ku(:,:,2);
        div_v = div_v1;
        
        
        if (mode <= 1) && (gap(k) < est)
            fprintf('Iter     Time     gap \n');
            fprintf('%d   %9.1f   %9.1e \n', k, time(k), gap(k));
            break;
        end
        
%         if (mode == 0) && (mod(k, 10) == 0) 
%             imagesc(p); colormap(gray(256));
%             fprintf('Iteration %d: The primal-dual gap is %e.\n', k, gap(k));
%             drawnow;
%         end
        
        if (mode == 3) && (time(k) > maxtime)
            break;
        end
%         %% updating u,v
%     v = v1;    u = u1;    Kv = Kv + th*(Kx-Kv);
    end

    gap = gap(1:k);
    time = time(1:k);  
  
end
