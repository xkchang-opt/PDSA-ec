function z = dctsolve(b, tau1, alpha)  
    % Solution of alpha u - tau1 Laplace u = b via DCT      
    % ------------------------------------------------
    %
    % Usage: u = dctsolve(b, tau1, alpha) 
    %    
    %   b           - right-hand side
    %   tau1, alpha - parameters of the equation
    %    
    % Copyright 2015 Kristian Bredies (kristian.bredies@uni-graz.at) 
    % and Hongpeng Sun (hpsun@amss.ac.cn).
    % 
    % If you use parts of this code, please cite:
    % 
    %   Kristian Bredies and Hongpeng Sun. 
    %   Preconditioned Douglas-Rachford algorithms for TV and TGV 
    %   regularized variational imaging problems. 
    %   Journal of Mathematical Imaging and Vision, 
    %   52(3):317-344, 2015. 
    
    [n,m] = size(b);
    dag = zeros(n,m);
    t = 0:n-1;
    r = 0:m-1;
    lameigrow = tau1*(2 - 2*cos(pi*t/n)); 
    lameigcol = tau1*(2 - 2*cos(pi*r/m));
    dag = bsxfun(@plus, lameigrow', lameigcol) + alpha;
    b1 = dct2(b, n,m);
    y1 = b1./dag;
    z = idct2(y1, n, m);
    return
end
% operator :  alpha I - tau1 \laplace 