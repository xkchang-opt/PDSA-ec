function [u, gap, time] = tv_gr(f, maxits, maxtime, est, lambda, step, mode)
    % VU for L^2-TV denoising demonstration script
    % 
    % Golden ratio primal-dual algorithm
    % --------------------------------------------
    %    
    % mode (optional) - demonstration mode
    %      'demo' (default) - demonstrate the method
    %      'iter' - record primal-dual gap for a fixed number of iterations
    %      'time' - record primal-dual gap for a fixed time interval
    %      'tol'  - record iterations/time to reach a certain tolerance
    %      'all'  - perform all tests
    %    
    % mode: 0 - demo, 1 - est, 2 - iter, 3 - time
    
    disp('**********************************************************')
    disp('Chang-Yang Golden ratio PDA for image denoising')
    disp('**********************************************************') 

    tstart = tic; %for comparison with time 
    gap = zeros(maxits,1);
    time = zeros(maxits,1);

    dxp = @(u)diffop(u,2,0);
    dxm = @(u)diffop(u,2,1);
    dyp = @(u)diffop(u,1,0);
    dym = @(u)diffop(u,1,1);
    
    [m,n] = size(f);
    
    u = f;
    z = u; 
    v = zeros(m,n,2);
   th = step{1,1};
   tau = step{2,1};
   sig  = step{3,1};
   div_v = dxm(v(:,:,1)) + dym(v(:,:,2));  %% -K^*v
    for k = 1:maxits 
        z = z + th * (u-z);
        u = (z + tau*(div_v + f))/(1 + tau);     %% x = P_tau g (x - tau K^*v)
        
      
        vt(:,:,1) = v(:,:,1) + sig*dxp(u);
        vt(:,:,2) = v(:,:,2) + sig*dyp(u);
        v = reproject(vt, lambda);
        
    
        %%%%%%%%%%%%%%% gap 
   
        % fro norm of u -f
        g1 = (norm(u - f,'fro'))^2/2;
        % TV norm
        g2 = lambda*sum(sum(sqrt(dxp(u).^2 + dyp(u).^2)));     
    
        % dual
        div_v = dxm(v(:,:,1)) + dym(v(:,:,2));
        g3 = (norm(div_v, 'fro'))^2/2;
        % inner product
        g4 = sum(sum(f.*div_v));
        
        %%%%%%%%%%%%%%%%% test modes

        gap(k) = (g1+g2+g3+g4)/(n*m);
        time(k) = toc(tstart);
        
        if (mode <= 1) && (gap(k) < est)
            fprintf('Iter     Time     gap \n');
            fprintf('%d   %9.1f   %9.1e \n', k, time(k), gap(k));
            break;
        end
        
%         if (mode == 0) && (mod(k, 10) == 0) 
%             imagesc(p); colormap(gray(256));
%             fprintf('Iteration %d: The primal-dual gap is %e.\n', k, gap(k));
%             drawnow;
%         end
        
        if (mode == 3) && (time(k) > maxtime)
            break;
        end
    end

    gap = gap(1:k);
    time = time(1:k);  
  
end
