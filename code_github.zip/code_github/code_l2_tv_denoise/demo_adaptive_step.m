 %%%%%%%%%
 %% show the results for TV-regularized variational imaging problems
 clear all
 clc;
 % compile mex files
%     mex diffop.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
%     mex reproject.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
%     mex rbsmooth.c CFLAGS="\$CFLAGS -fopenmp" LDFLAGS="\$LDFLAGS -fopenmp"
    
type = 1;    
if type == 1% noise level: 0.1
    u_orig = double(imread('butterfly.png'))/255;
%     f = double(imread('butterflynoise01.png'))/255;
%     lambda = 0.1; %regularization parameter
else
    %u_orig   =  double(imread('Cameraman.bmp'))/255;   % 256x256  man 
    u_orig   =  double(imread('Barbara.png'))/255; 
end 
  mu = 0;
  sigma = 0.05;
  f = imnoise(u_orig, 'gaussian', mu, sigma);
  lambda = 0.2; %regularization parameter    

L = sqrt(8);
mode = 0;
est = 1e-7;
maxits = 50000;
maxtime = 100; % irrelevant here

%% primal-dual splitting algorithm with convex combination and larger step sizes
th = 0.4;
eta = 1.1;  gam = 1.4; 
tau = sqrt(gam)/L;  sig = tau;  
step = {th; eta; tau;sig};
[u_ec_a, gap_ec_a, time_ec_a] = tv_ec_adap(f, maxits, maxtime, est, lambda, step, mode);
kkk
%% primal-dual splitting algorithm with convex combination and larger step sizes
th = 1/5;   eta = 7/6;  gam = 1.5; 
tau = sqrt(gam)/L;  sig = tau;  
step = {th; eta; tau;sig};
[u_ec, gap_ec, time_ec] = tv_ec(f, maxits, maxtime, est, lambda, step, mode);

%% CP-PDHG
relax = 1;
 tau = 1/L;  sig = 1/L;  
 step = {tau;sig};
 [u_cp1, gap_cp1, time_cp1] = tv_vu(f, maxits, maxtime, est, lambda, relax,step, mode);


%% CP-PDHG
relax = 1;
 tau = 1/L;  sig = 1/L;  
 step = {tau;sig};
 [u_cp1_a, gap_cp1_a, time_cp1_a] = tv_vu_adap(f, maxits, maxtime, est, lambda, relax,step, mode);







figure(2);
% p1 = semilogy(time_cp1, gap_cp1,'b-');
% hold on;
% p2 = semilogy(time_cp1_a, gap_cp1_a,'m--');
% p3 = semilogy(time_ec, gap_ec,'r-');
% p4 = semilogy(time_ec_a, gap_ec_a,'k--');
p1 = semilogy(gap_cp1,'b-');
hold on;
p2 = semilogy(gap_cp1_a,'m--');
p3 = semilogy(gap_ec,'r-');
p4 = semilogy(gap_ec_a,'k--');


xlabel({'Time(second)'},'Interpreter','latex','FontSize',14);
ylabel({'Normalized Primal-Dual Gap'},'Interpreter','latex','FontSize',14);
legend([p1 p2 p3 p4],{'CP-PDHG','CP-PDHG (adaptive)','Alg.3.1','Alg.3.1 (adaptive)'});
%legend([p1 p11 p2 p3],{'CP-PDHG','CP-PDHG (relaxed)','PDAc','Alg.3.1'});
set(gca,'FontSize',14,'LineWidth',2);
% axis([0 300 1e-7 1e-4]);


figure(1); 
subplot(1,3,1);
imshow(u_orig,'border','tight'); colormap(gray(256));axis off; title('original');
subplot(1,3,2);
imshow(f,'border','tight'); colormap(gray(256));axis off; title('noisy');
subplot(1,3,3);
imshow(u_ec,'border','tight'); colormap(gray(256)); axis off; title('TVdenoised from Alg. 3.1');

       
