%%  L1-regularized least-squares example
%%  solve problem 
%%  min_x  1/2 \|Ax-b\|^2 + lam * \|x\|_1
%%
%% Generate problem data
clear all
clc
seed = 1;
addpath('PDA_K')
rng(seed,'twister');
randn('seed', seed);
rand('seed',seed);

aa=[];
alpha = 0;
type = 2;
switch type
case {1}   
    n = 500;
    m = 300;
    s = 20;
    % 
    % A = randn(m,n);
    B = randn(m,n);
    p = 0.9;
    A = zeros(m,n);
    A(:,1) = B(:,1)/sqrt(1-p^2);
    for j =2:n
        A(:,j) = p*A(:,j-1) + B(:,j);
    end
    w = randn(n,1);
    w(s:end) = 0;
    randIndex_s = randperm(length(w));
    w = w(randIndex_s);  
    nu = randn(m,1);
    b = A*w + nu;
case {2}
    n = 2000;
    m = 1000;
    s = 100;
    
    B = randn(m,n);
    p = 0.9;
    A = zeros(m,n);
    A(:,1) = B(:,1)/sqrt(1-p^2);
    for j =2:n
        A(:,j) = p*A(:,j-1) + B(:,j);
    end
    
    w = unifrnd(-10,10, n,1);
    w(s:end) = 0;
    randIndex_s = randperm(length(w));
    w = w(randIndex_s);
    nu = randn(m,1);
    b = A*w + nu;
end


    ATA = A'*A;
    [v,d] = eigs(ATA);
    eig_AA = max(d(:));
%      sqrt(eig_AA)
%      llll

    lambda_max = 0.1*norm( A'*b, 'inf' );
    lambda = lambda_max;
%%
if type~=2
   %------------- CVX ------------------%
    disp('starting cvx...');
    tic;
    cvx_begin quiet
        cvx_precision high 
        variable x(n);
        minimize( 1/2*norm(A*x-b,2)^2+ lambda*norm(x,1) );
    cvx_end
    time_mosek = toc;
    display(time_mosek);
    obj    = 1/2*norm(A*x-b,2)^2+ lambda*norm(x,1);
else
    %% obj
    if p==0.5;
        obj = 9.219380320305470e+05;  %% p=0.5
    else
        obj = 4.319617116247723e+06;   %% p=0.9
    end
end

   %% basic parameters
     eps_rel = 1e-10;
     max_iter = 1e+6;
  

   %% CP-PDHG
    th = [];   relax = 1; gam = 1/eig_AA;
    input = {A;b;lambda;obj;eig_AA;th;relax; gam; eps_rel};
    [x21, history21] = lassoCP_K(input);
    
    %% relaxed CP-PDHG
    relax = 1.5; 
    input = {A;b;lambda;obj;eig_AA;th;relax; gam; eps_rel};
    [x2, history2] = lassoCP_K(input);
   %% Chang and Yang convex combination based PDHG (PDAc)
    psi = 1.6;  
    gam = 1.6/eig_AA;  eta=[];
    input = {A;b;lambda;obj;eig_AA;psi;eta; gam; eps_rel};
    [x3, history3] = lassoPDAc_K(input);
    
    %% primal-dual splitting algorithm with convex combination and larger step sizes
    th = 0.99/5;    eta = 7/6;    gam = 1.5;
    adp_para = 0;
    input = {A;b;lambda;obj;eig_AA;th;eta; gam; eps_rel;max_iter;adp_para};
    [x5, history5] = lassoRS_K(input); 
    
  %% Alg. 3.1  with adaptive theta and eta
    th = 0.99/5;  eta= 7/6;   gam = 1.5; 
    adp_para = 1;
    input = {A;b;lambda;obj;eig_AA;th;eta; gam; eps_rel;max_iter;adp_para};
    [x4, history4] = lassoRS_K(input);  
    
%% Plot results
figure(1)
h11 = plot(history21.time, history21.objval,'b-');
hold on
h1 = plot(history2.time, history2.objval,'k--');
h2 = plot(history3.time,history3.objval,'m-');
h3 = plot(history5.time,history5.objval,'r--');
h4 = plot(history4.time,history4.objval,'g-');


legend([h11 h1,h2,h3,h4],'CP-PDHG','CP-PDHG (relaxed)','PDAc','Alg.3.1',...
    'Alg.3.1-adaptive $(\theta,\eta)$','Interpreter','latex');
xlabel('CPU time, seconds','Interpreter','latex','FontSize',14)
ylabel({'$e_{\mbox{obj}}(x_n)$'},'Interpreter','latex','FontSize',14)
set(gca,'FontSize',14,'LineWidth',2);
set(gca,'yscale','log');

% 
%     clear A 
%     clear b



