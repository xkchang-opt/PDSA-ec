%%  L1-regularized least-squares example
%%  solve problem 
%%  min_x  1/2 \|Ax-b\|^2 + lam * \|x\|_1
%%
%% Generate problem data
clear all
clc
seed = 1;
addpath('PDA_K')
 rng(seed,'twister');
 randn('seed', seed);
 rand('seed',seed);

aa=[];
alpha = 0;
type = 1;
switch type
case {1}   
    n = 500;
    m = 300;
    s = 20;
    % 
    % A = randn(m,n);
    B = randn(m,n);
    p = 0.9;
    A = zeros(m,n);
    A(:,1) = B(:,1)/sqrt(1-p^2);
    for j =2:n
        A(:,j) = p*A(:,j-1) + B(:,j);
    end
    w = randn(n,1);
    w(s:end) = 0;
    randIndex_s = randperm(length(w));
    w = w(randIndex_s);  
    nu = randn(m,1);
    b = A*w + nu;
case {2}
    n = 2000;
    m = 1000;
    s = 100;
    
    B = randn(m,n);
    p = 0.9;
    A = zeros(m,n);
    A(:,1) = B(:,1)/sqrt(1-p^2);
    for j =2:n
        A(:,j) = p*A(:,j-1) + B(:,j);
    end
    
    w = unifrnd(-10,10, n,1);
    w(s:end) = 0;
    randIndex_s = randperm(length(w));
    w = w(randIndex_s);
    nu = randn(m,1);
    b = A*w + nu;
end


    ATA = A'*A;
    [v,d] = eigs(ATA);
    eig_AA = max(d(:));
%      sqrt(eig_AA)
%      llll

    lambda_max = 0.1*norm( A'*b, 'inf' );
    lambda = lambda_max;
%%
if type~=2
   %------------- CVX ------------------%
    disp('starting cvx...');
    tic;
    cvx_begin quiet
        cvx_precision high 
        variable x(n);
        minimize( 1/2*norm(A*x-b,2)^2+ lambda*norm(x,1) );
    cvx_end
    time_mosek = toc;
    display(time_mosek);
    obj    = 1/2*norm(A*x-b,2)^2+ lambda*norm(x,1);
else
    %% obj
    if p==0.5;
        obj = 9.219380320305470e+05;  %% p=0.5
    else
        obj = 4.319617116247723e+06;   %% p=0.9
    end
end

    %% Solve problem
%        [x, history1] = lassoADMM_Boyd(A, b, lambda, 1, 1);
%        obj    = 1/2*norm(A*x-b,2)^2+ lambda*norm(x,1);
     eps_rel = 1e-10;
     max_iter = 1e+6;
    
   %% CP-PDA
    th = [];   eta = []; gam = 1/eig_AA;
    input = {A;b;lambda;obj;eig_AA;th;eta; gam; eps_rel};
    [x2, history2] = lassoCP_K(input);
   %% PDAc
    psi = 1.95;  
    gam = 1.9/eig_AA; 
    input = {A;b;lambda;obj;eig_AA;psi;eta; gam; eps_rel};
    [x3, history3] = lassoPDAc_K(input);
    
  %% Alg. 3.1
    th = 0.5;  gam = 1.5;
    eta = 2 - 1.01*gam/(2-th);
    
    adp_para = 1;
    input = {A;b;lambda;obj;eig_AA;th;eta; gam; eps_rel;max_iter;adp_para};
    [x4, history4] = lassoRS_K(input);
    
    %% Resolvent Splitting Alg. 3.1
    th = 0.5;  gam = 1.5;
    eta = 2 - 1.01*gam/(2-th);
    adp_para = 0;
    input = {A;b;lambda;obj;eig_AA;th;eta; gam; eps_rel;max_iter;adp_para};
    [x5, history5] = lassoRS_K(input);     
    
%% Plot results
figure(1)
h1 = plot(history2.time, history2.objval,'b--');
hold on
h2 = plot(history3.time,history3.objval,'m-.');
h3 = plot(history4.time,history4.objval,'r-');
h4 = plot(history5.time,history5.objval,'k:');


legend([h1,h2,h4,h3],'CP-PDA','PDAc','Alg.3.1',...
    'Alg.3.1-adaptive','Interpreter','latex');
xlabel('CPU time, seconds','Interpreter','latex','FontSize',14)
ylabel({'$e_{\mbox{obj}}(x_n)$'},'Interpreter','latex','FontSize',14)
set(gca,'FontSize',14,'LineWidth',1);
set(gca,'yscale','log');

% 
%     clear A 
%     clear b



