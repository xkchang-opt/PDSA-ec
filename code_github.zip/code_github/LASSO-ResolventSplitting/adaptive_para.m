function [th, eta, it_pinf,it_dinf] = adaptive_para(iter, pinf, dinf, th, eta,gam, it_pinf,it_dinf)

    MUmin = 0.1;
    MUmax = 2-gam/(2-MUmin);
  
 dtmp=pinf/dinf;  
 if iter<=21;         kk=3;
 elseif iter<=61;     kk=6;    
 elseif iter<=121;    kk=50;
 else                kk=100;  
 end

 if dtmp <= 4/5;   
     it_pinf = it_pinf+1;     it_dinf = 0;
    if it_pinf>kk
       th = min(5/4 *th, MUmax);    
       eta = max(2-gam/(2-th), MUmin);
       it_pinf=0;
    end
  else if dtmp > 5/4;    
          it_dinf = it_dinf+1; it_pinf = 0;
          if it_dinf>kk
             eta = min(5/4 *eta, MUmax);
             th = max(2-gam/(2-eta), MUmin);            
             it_dinf = 0;
          end
       end
 end
 
 
end