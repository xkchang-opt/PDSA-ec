function [x, history] = lassoCP_K(input)
t_start = tic;
% Global constants and defaults
QUIET    = 0;
MAX_ITER = 1e+6;
A = input{1,1};
b = input{2,1};
lambda = input{3,1};
obj = input{4,1};
%L = input{5,1};
th = input{6,1};
eta = input{7,1};
gam = input{8,1};
eps_rel = input{9,1};
% Data preprocessing
[m, n] = size(A);

% Resolvent Splitting solver
x = ones(n,1);  Ax = A*x;
y = ones(m,1);
tau = sqrt(gam);
sig = tau;

disp('CP-PDA');

fprintf('%3s \t%10s\t%10s \t%10s\n', 'iter', 'r norm',  'objective', 'CPU time');
for k = 1:MAX_ITER
   %% x,y-update
    x1 = shrinkage(x - tau*A'*y, tau*lambda);
    Ax1 = A*x1;
    y1  = (y+sig*(2*Ax1-Ax) - sig*b)/(1+sig);
    
    history.r_norm(k) = max(norm(x-x1), norm(y-y1));
    x = x1; y = y1; Ax = A*x1;

    % diagnostics, reporting, termination checks
    history.objval(k)  = abs(objective(A, b, lambda, x)-obj)/obj;
    history.time(k)=toc(t_start);
    

    if ~QUIET && mod(k,500)==1
        fprintf('%3d \t%10.5e \t%10.5e \n', k, ...
            history.r_norm(k), history.objval(k));
    end

    if (history.objval(k) < eps_rel)
   history.iteration=k;
   history.time(k)=toc(t_start);
   fprintf('%3d \t%10.3e \t%10.6e \t%10.3f\n', k, ...
            history.r_norm(k), history.objval(k),history.time(k));
         break;
    end

end

if ~QUIET
    toc(t_start);
end
end

function p = objective(A, b, lambda, z)
    p = ( 1/2*sum((A*z - b).^2) + lambda*norm(z,1) );
end

function z = shrinkage(x, kappa)
    z = max( 0, x - kappa ) - max( 0, -x - kappa );
end

function [L U] = factor(A, rho)
    [m, n] = size(A);
    if ( m >= n )    % if skinny
       L = chol( A'*A + 1/rho *speye(n), 'lower' );
    else            % if fat
       L = chol( speye(m) + rho*(A*A'), 'lower' );
    end

    % force matlab to recognize the upper / lower triangular structure
    L = sparse(L);
    U = sparse(L');
end