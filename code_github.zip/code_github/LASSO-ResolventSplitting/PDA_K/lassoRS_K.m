function [x, history] = lassoRS_K(input)
t_start = tic;
% Global constants and defaults
QUIET    = 0;
A = input{1,1};
b = input{2,1};
lambda = input{3,1};
obj = input{4,1};
L = input{5,1};
th = input{6,1};
eta = input{7,1};
gam = input{8,1};
eps_rel = input{9,1};
MAX_ITER = input{10,1};
adp_para = input{11,1};
% Data preprocessing
[m, n] = size(A);

%% parameters for adaptive
it_pinf = 0;  it_dinf = 0;

% Resolvent Splitting solver
tau = sqrt(gam)/sqrt(L);
sig = tau;
t_s = tau*sig;

v = ones(n,1); Av = A*v; 
y = ones(m,1);
u = t_s * Av - tau *y;
if adp_para ==1
    disp('Alg.3.1 with adaptive eta and theta');
else
    disp('Alg.3.1');
end
    

fprintf('%3s \t%10s\t%10s \t%10s\n', 'iter', 'r norm',  'objective', 'CPU time');
for k = 1:MAX_ITER
   %% y,x-update
    x = shrinkage(v - tau*A'*(sig* Av-u/tau), tau*lambda);
    Ax = A*x;
    z = (Av+Ax-u/t_s + b/sig)/(1+1/sig);
    
    v1 = v + th*(x-v);
    u1 = u  + t_s * eta *(z-Ax);

    pinf = norm(v1-v);
    dinf = norm(u1-u); %% w-Ax
    
    if adp_para == 1 
          [th,eta,  it_pinf,it_dinf] = adaptive_para(k, pinf, dinf,th, eta, gam, it_pinf,it_dinf);
    end

    history.r_norm(k) = max(pinf,dinf);
    %% updating u,v
    v = v1;    u = u1;    Av = Av + th*(Ax-Av);

    % diagnostics, reporting, termination checks
    history.objval(k)  = abs(objective(A, b, lambda, x)-obj)/(1+obj);
    history.time(k)=toc(t_start);
    

    if ~QUIET && mod(k,500)==1
        fprintf('%3d \t%10.5e \t%10.5e \n', k, ...
            history.r_norm(k), history.objval(k));
    end

    if (history.objval(k) < eps_rel)
   history.iteration=k;
   history.time(k)=toc(t_start);
   fprintf('%3d \t%10.3e \t%10.6e \t%10.3f\n', k, ...
            history.r_norm(k), history.objval(k),history.time(k));
         break;
    end

end

if ~QUIET
    toc(t_start);
end
end

function p = objective(A, b, lambda, z)
    p = ( 1/2*sum((A*z - b).^2) + lambda*norm(z,1) );
end

function z = shrinkage(x, kappa)
    z = max( 0, x - kappa ) - max( 0, -x - kappa );
end

