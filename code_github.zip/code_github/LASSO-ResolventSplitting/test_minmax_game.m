%% Test primal dual methods for solving minmax matrix game problems

clear all;
clc;
addpath('Minmax_game')
randn('seed', 1);
rand('seed',1);
%% Section 1 Choose any generator for random generation of data. In the paper we set gen = 1
type = 1;
switch type
case {1}
m = 100;
n = 100;
A = unifrnd(-1,1, m,n);
% B = orth(randn(n,n)); A = B*diag(randn(1,m)+1)*B';
case {2}
m = 100;
n = 100;
A = normrnd(0, 1, m, n);
case{3}
m = 100;
n = 100;
A = normrnd(-1, 1, m, n);
end
%% Section 2 Define parameters 
ATA=A'*A;
[v,d]=eigs(ATA);
L = sqrt(max(d(:)));

%% Section 3 Define the starting points  
x0 = ones(n,1)/n;
y0 = ones(m,1)/m;
eps_rel = 1e-10;
max_iter = 1e+6;

%% CP-PDHG 
relax = 1;
tau = 1/L;  sig = tau;
input = {tau; sig; x0; y0; eps_rel;relax;max_iter};
 [x11, history11] = minmax_game_CP(A, input);
%% relaxed CP-PDHG
 relax = 1.5;
input = {tau; sig; x0; y0; eps_rel;relax;max_iter};
 [x1, history1] = minmax_game_CP(A, input);
 
%% Chang and Yang convex combination based PDHG (PDAc)
psi = 1.6;  gam = 1.6;
relax = [];
tau = sqrt(gam)/L;  sig = tau;
input = {tau; sig; x0; y0; eps_rel;psi;relax;max_iter};
[x2, history2] = minmax_game_PDAc(A, input); 
 
 %% primal-dual splitting algorithm with convex combination and larger step sizes
th = 0.99/5;  eta = 7/6;   gam = 1.5;
 
tau = sqrt(gam)/L;  sig = tau;
adp_para = 0;
input = {tau; sig; x0; y0; eps_rel;th;eta;max_iter;adp_para;gam};
[x3, history3] = minmax_game_RS(A, input);


%% plot primal dual gap
figure(2)
h1 = semilogy(history11.time,history11.gap,'b-');
hold on;
h5 = semilogy(history1.time,history1.gap,'k--');
h2 = semilogy(history2.time,history2.gap,'m-');
h3 = semilogy(history3.time,history3.gap,'r--');


legend([h1 h5, h2, h3],'CP-PDHG','CP-PDHG (relaxed)','PDAc','Alg.3.1',...
    'Interpreter','latex');
xlabel('CPU time, seconds','Interpreter','latex','FontSize',14)
ylabel('PD gap $G(x_n,y_n)$','Interpreter','latex','FontSize',14)
set(gca,'FontSize',14,'LineWidth',2);

