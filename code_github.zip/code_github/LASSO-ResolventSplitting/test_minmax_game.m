%% Example Title
% Summary of example objective
clear all;
clc;
addpath('Minmax_game')
randn('seed', 1);
rand('seed',1);
%% Section 1 Choose any generator for random generation of data. In the paper we set gen = 100
type = 1;
switch type
case {1}
m = 100;
n = 100;
A = unifrnd(-1,1, m,n);
% B = orth(randn(n,n)); A = B*diag(randn(1,m)+1)*B';
case {2}
m = 100;
n = 100;
A = normrnd(0, 1, m, n);
case{3}
m = 100;
n = 100;
A = normrnd(-1, 1, m, n);
end
%% Section 2 Define parameters 
ATA=A'*A;
[v,d]=eigs(ATA);
L = sqrt(max(d(:)));

%% Section 3 Define the starting points  
x0 = ones(n,1)/n;
y0 = ones(m,1)/m;
eps_rel = 1e-10;
max_iter = 1e+6;

%% CP-PDA
relax = 1;
tau = 1/L;  sig = tau;
input = {tau; sig; x0; y0; eps_rel;relax;max_iter};
 [x1, history1] = minmax_game_CP(A, input);
 
%% PDAc
psi = 1.6;  gam = 1.6;
eta = [];
tau = sqrt(gam)/L;  sig = tau;
input = {tau; sig; x0; y0; eps_rel;psi;eta;max_iter};
[x2, history2] = minmax_game_PDAc(A, input); 
 
 %% Resolvent Splitting Alg. 3.1
 th = 0.5;  gam = 1.5;
eta = 0.99*(2-gam/(2-th));
 
tau = sqrt(gam)/L;  sig = tau;
adp_para = 0;
input = {tau; sig; x0; y0; eps_rel;th;eta;max_iter;adp_para;gam};
[x3, history3] = minmax_game_RS(A, input);


%%
th = 0.5;  gam = 1.5; 
eta = 0.99*(2-gam/(2-th));

tau = sqrt(gam)/L;  sig = sqrt(gam)/L;
adp_para = 1;
input = {tau; sig; x0; y0; eps_rel;th;eta;max_iter;adp_para;gam};
[x4, history4] = minmax_game_RS(A, input);



 
%% plot results
% figure(1)
% h1 = semilogy(history1.time,history1.rel,'b--');
% hold on;
% h2 = semilogy(history2.time,history2.rel,'m-.');
% h3 = semilogy(history3.time,history3.rel,'r-');
% h4 = semilogy(history4.time,history4.rel,'c-');
% 
% %legend([h1,h2,h3],'CP','Relaxed CP with $\lambda =1.6$','NE-PPA-inexact','Interpreter','latex');
% legend([h1,h2,h3],'CP','PDAc','Alg.3.1','Interpreter','latex');
% xlabel('CPU time, seconds','Interpreter','latex','FontSize',14)
% ylabel('$\|w^{k+1}-w^{k}\|$','Interpreter','latex','FontSize',14)
% set(gca,'FontSize',14,'LineWidth',1);


figure(2)
h1 = semilogy(history1.time,history1.gap,'b--');
hold on;
h2 = semilogy(history2.time,history2.gap,'m-.');
h3 = semilogy(history3.time,history3.gap,'k:');
h4 = semilogy(history4.time,history4.gap,'r-');


legend([h1, h2, h3, h4],'CP-PDHG','PDAc','Alg.3.1',...
    'Alg.3.1-adaptive','Interpreter','latex');
xlabel('CPU time, seconds','Interpreter','latex','FontSize',14)
ylabel('PD gap $G(x_n,y_n)$','Interpreter','latex','FontSize',14)
set(gca,'FontSize',14,'LineWidth',1);

