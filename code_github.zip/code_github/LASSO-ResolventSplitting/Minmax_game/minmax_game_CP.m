function [x, history] = minmax_game_CP(A, input)
%% Primal-dual algorithm of Pock and Chambolle for the problem 
%%  min_x max_y [<Kx,y> + g(x) - f*(y)] 
%%  min_{x in ��n} max_{y in ��m} <Kx,y> 
%% ��m denote the standard unit simplices in R^m

t_start = tic;
tau = input{1,1};
sig = input{2,1};
x = input{3,1};
y = input{4,1};
eps_rel = input{5,1};
relax = input{6,1};
max_iter = input{7,1};

Ax = A*x;
    disp('**********************************************************')
    if relax >1
        disp('Chambolle-Pock PDA (relaxed version) for minmax game')
    else
        disp('Chambolle-Pock PDA for minmax game')
    end
fprintf('\n %3s \t%10s\t%10s  %3s \n', 'iter', ...
      'rel-norm', 'gap','CPU time');
for k = 1:max_iter
    Aty = A'*y;
    x1 = projsplx(x - tau * Aty);
    Ax1 = A*x1;
    y1 = projsplx(y + sig * (2*Ax1 - Ax));

    
    history.rel(k) = norm([x1-x;y-y1]);
    history.gap(k) = max(Ax) - min(Aty);
    history.time(k)= toc(t_start);
    if history.gap(k) <eps_rel || k == max_iter;
       fprintf('%3d \t%10.3e \t%10.3e \t%10.2f \n', k, ...
            history.rel(k), history.gap(k), history.time(k));
        break
    else
        if relax == 1
            x = x1;  y = y1;   Ax = Ax1;
        else
            x = relax * x1 - (relax-1)*x;
            y = relax * y1 - (relax-1)*y;
            Ax = relax * Ax1 - (relax-1)*Ax;
        end
    end


end

