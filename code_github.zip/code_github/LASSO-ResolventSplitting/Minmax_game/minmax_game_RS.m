function [x, history,k] = minmax_game_RS(A, input)
%% Primal-dual algorithm of Pock and Chambolle for the problem 
%%  min_x max_y [<Kx,y> + g(x) - f*(y)] 
%%  min_{x in ��n} max_{y in ��m} <Kx,y> 
%% ��m denote the standard unit simplices in R^m

t_start = tic;
tau = input{1,1};
sig = input{2,1};
x = input{3,1};
y = input{4,1};
eps_rel = input{5,1};
th = input{6,1};
eta = input{7,1};
max_iter = input{8,1};
adp_para = input{9,1};
gam  = input{10,1};

%% parameters for adaptive
it_pinf = 0;  it_dinf = 0; 

v = x; Av = A*v;  Ax_Av=0;%% Ax=Av;
Aty = A'*y;

if adp_para == 1
     disp('PDS with adaptive for minmax game');
else
     disp('PDS for minmax game');
end
    
fprintf('\n %3s \t%10s\t%10s  %3s \n', 'iter', ...
      'rel-norm', 'gap','CPU time');
for k = 1:max_iter
    v = v + th * (x-v);
    Av = Av + th * Ax_Av;
    x = projsplx(v - tau*Aty);
    Ax= A*x;
    Ax_Av = Ax-Av;
    z = projsplx(y+sig*Ax);
    %Av_ = Ax + th/eta * (Ax-Av);
    %y1 = y + eta*sig*(Av_- projsplx(y/sig+ Ax));
    y1 =(1-eta)*y+ eta*z + sig*th*(Ax_Av);
   %% using x-v~=x1-x for cheap computation
   pinf = th*norm(x-v); 
   dinf = norm(tau*(y1-y)-tau*sig*th*(Ax_Av)); %% w-Ax 
    if adp_para == 1 
          [th,eta,  it_pinf,it_dinf] = adaptive_para(k, pinf, dinf,th,eta,  gam, it_pinf,it_dinf);
    end
    

    history.rel(k) = max(pinf,dinf);
    history.gap(k) = max(Ax) - min(Aty);
    history.time(k)= toc(t_start);
    if history.gap(k) <eps_rel || k == max_iter;
       fprintf('%3d \t%10.3e \t%10.3e \t%10.2f \n', k, ...
            history.rel(k), history.gap(k), history.time(k));
        break
    else
%         if mod(k,5000)==1
%             fprintf('%3d \t%10.3e \t%10.3e \t%10.2f \n', k, ...
%             history.rel(k), history.gap(k), history.time(k));
%         end
      y = y1; Aty = A'*y;
    end


end

